#!/usr/bin/env python3
"""
tests/evidence_harness.py — Deterministic evidence test harness.

Usage (from seven7_ocr_service/ directory):
    python3 tests/evidence_harness.py

Usage (from project root):
    python3 seven7_ocr_service/tests/evidence_harness.py

Produces:
    tests/evidence_report.json — structured JSON evidence report
    stdout                     — human-readable summary

No pytest. No running server. Direct Python imports only.
Concrete observed outputs only — no simulated results.
"""

from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Path setup ────────────────────────────────────────────────────────────────
# Allow running from project root or from seven7_ocr_service/
_HERE = Path(__file__).resolve().parent          # tests/
_SVC  = _HERE.parent                             # seven7_ocr_service/
if str(_SVC) not in sys.path:
    sys.path.insert(0, str(_SVC))

import numpy as np
import cv2

from app.backends.paddle_backend   import PaddleOCRBackend
from app.backends.tesseract_backend import TesseractBackend
from app.services.ensemble_service  import run_ensemble
from app.services.ocr_service       import run_ocr, make_error_response
from app.backends.policy            import select_backend
from app.backends.registry          import BackendRegistry
from app.errors                     import OCRServiceError, ErrorCode

# ── Image generators ──────────────────────────────────────────────────────────

def make_text_image(text: str = "450K", w: int = 200, h: int = 48) -> np.ndarray:
    """
    Synthetic light-background image with clear dark text.
    Designed to be readable by Tesseract PSM 11.
    """
    img = np.full((h, w, 3), 240, dtype=np.uint8)
    cv2.putText(
        img, text, (8, h - 10),
        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (15, 15, 15), 2,
        lineType=cv2.LINE_AA,
    )
    return img


def make_blank_image(w: int = 200, h: int = 48) -> np.ndarray:
    """Pure white image — expected to produce NoTextDetected from both backends."""
    return np.full((h, w, 3), 255, dtype=np.uint8)


# ── Single-backend runner ─────────────────────────────────────────────────────

def run_single(
    backend_name: str,
    backend,
    img: np.ndarray,
    label: str,
) -> Dict[str, Any]:
    """Run OCR on a single backend; capture success or failure without raising."""
    h, w = img.shape[:2]

    # Build a minimal one-entry registry for policy use
    reg = BackendRegistry()
    reg.register(backend_name, backend)

    try:
        active = select_backend(reg, requested_name=backend_name)
    except OCRServiceError as err:
        return {
            "label":        label,
            "backend_name": backend_name,
            "success":      False,
            "error_code":   err.code.value,
            "error_message": err.message,
            "full_text":    None,
            "mean_confidence": None,
            "ensemble_meta": None,
            "image_label":  label,
        }

    try:
        resp = run_ocr(
            backend=active,
            img_bgr=img,
            width=w,
            height=h,
            min_confidence=0.0,
            return_words=False,
        )
        return {
            "label":           label,
            "backend_name":    backend_name,
            "success":         resp.success,
            "error_code":      resp.error_code,
            "error_message":   resp.error_message,
            "full_text":       resp.full_text,
            "mean_confidence": resp.mean_confidence,
            "ensemble_meta":   None,
            "image_label":     label,
        }
    except OCRServiceError as err:
        err_resp = make_error_response(err, backend=backend_name, width=w, height=h)
        return {
            "label":           label,
            "backend_name":    backend_name,
            "success":         False,
            "error_code":      err_resp.error_code,
            "error_message":   err_resp.error_message,
            "full_text":       None,
            "mean_confidence": None,
            "ensemble_meta":   None,
            "image_label":     label,
        }


# ── Ensemble runner ───────────────────────────────────────────────────────────

def run_ens(
    paddle, tess,
    img: np.ndarray,
    label: str,
) -> Dict[str, Any]:
    """Run ensemble; extract summary."""
    h, w = img.shape[:2]
    resp = run_ensemble(
        paddle_backend=paddle,
        tess_backend=tess,
        img_bgr=img,
        width=w,
        height=h,
        min_confidence=0.0,
        return_words=False,
    )

    meta_summary = None
    if resp.ensemble_meta:
        meta_summary = {
            k: {
                "success":         v.success,
                "full_text":       v.full_text,
                "mean_confidence": v.mean_confidence,
                "error_code":      v.error_code,
            }
            for k, v in resp.ensemble_meta.items()
        }

    return {
        "label":           label,
        "backend_name":    "ensemble",
        "success":         resp.success,
        "error_code":      resp.error_code,
        "error_message":   resp.error_message,
        "full_text":       resp.full_text,
        "mean_confidence": resp.mean_confidence,
        "ensemble_meta":   meta_summary,
        "image_label":     label,
    }


# ── Print helpers ─────────────────────────────────────────────────────────────

def print_result(r: Dict[str, Any], rule_tag: str = "") -> None:
    tag = f"  [{rule_tag}]" if rule_tag else ""
    icon = "OK" if r["success"] else "FAIL"
    print(f"  [{icon}]{tag} backend={r['backend_name']!r}  image={r['image_label']!r}")
    print(f"        success={r['success']}  error_code={r['error_code']!r}")
    print(f"        full_text={r['full_text']!r}  mean_conf={r['mean_confidence']}")
    if r["ensemble_meta"]:
        for k, v in r["ensemble_meta"].items():
            print(f"        meta[{k}]: success={v['success']}  "
                  f"text={v['full_text']!r}  err={v['error_code']!r}")


# ── Main harness ──────────────────────────────────────────────────────────────

def main() -> None:
    started = datetime.now(timezone.utc).isoformat()
    print(f"\n{'='*62}")
    print(f"  seven7 OCR Evidence Harness  —  {started}")
    print(f"{'='*62}\n")

    # ── Backend init ──────────────────────────────────────────────────────────
    print("Initialising backends …")
    paddle = PaddleOCRBackend()
    tess   = TesseractBackend()

    t0 = time.monotonic()
    paddle.warmup()
    tess.warmup()
    warmup_s = round(time.monotonic() - t0, 2)

    print(f"  paddle    : {'available' if paddle.is_available else 'UNAVAILABLE'}"
          + (f"  ({paddle.unavailable_reason})" if not paddle.is_available else ""))
    print(f"  tesseract : {'available' if tess.is_available else 'UNAVAILABLE'}"
          + (f"  ({tess.unavailable_reason})" if not tess.is_available else ""))
    print(f"  warmup time: {warmup_s}s\n")

    # ── Synthetic images ──────────────────────────────────────────────────────
    img_text  = make_text_image("450K")
    img_blank = make_blank_image()

    # Save test images for audit
    out_dir = _HERE
    cv2.imwrite(str(out_dir / "img_text.png"),  img_text)
    cv2.imwrite(str(out_dir / "img_blank.png"), img_blank)
    print(f"Test images saved to {out_dir}/\n")

    results: List[Dict[str, Any]] = []
    rule_evidence: Dict[str, str] = {}

    # ─────────────────────────────────────────────────────────────────────────
    # TC-01: Single tesseract, text image  (control — confirms tess works)
    # ─────────────────────────────────────────────────────────────────────────
    print("TC-01  tesseract / text image  (control)")
    r = run_single("tesseract", tess, img_text, "text_image")
    print_result(r)
    results.append({"tc": "TC-01", "description": "single tesseract, text image", **r})
    print()

    # ─────────────────────────────────────────────────────────────────────────
    # TC-02: Single paddle, text image  (confirms paddle unavailable)
    # ─────────────────────────────────────────────────────────────────────────
    print("TC-02  paddle / text image  (unavailability control)")
    r = run_single("paddle", paddle, img_text, "text_image")
    print_result(r)
    results.append({"tc": "TC-02", "description": "single paddle, text image", **r})
    print()

    # ─────────────────────────────────────────────────────────────────────────
    # TC-03: Ensemble, text image  → RULE C expected
    # paddle unavailable + tesseract succeeds → ENSEMBLE_PARTIAL_FAILURE
    # ─────────────────────────────────────────────────────────────────────────
    print("TC-03  ensemble / text image  (RULE C expected)")
    r = run_ens(paddle, tess, img_text, "text_image")
    print_result(r, "RULE C")
    results.append({"tc": "TC-03", "description": "ensemble text image — RULE C", **r})
    if r["error_code"] == ErrorCode.ENSEMBLE_PARTIAL_FAILURE:
        rule_evidence["RULE_C"] = "EVIDENCED — TC-03"
    elif r["success"]:
        rule_evidence["RULE_A"] = "EVIDENCED — TC-03 (both succeeded, matched)"
    print()

    # ─────────────────────────────────────────────────────────────────────────
    # TC-04: Ensemble, blank image  → RULE D expected
    # tesseract returns no text → NoTextDetectedError; paddle unavailable
    # Both fail → ENSEMBLE_BOTH_FAILED
    # ─────────────────────────────────────────────────────────────────────────
    print("TC-04  ensemble / blank image  (RULE D expected)")
    r = run_ens(paddle, tess, img_blank, "blank_image")
    print_result(r, "RULE D")
    results.append({"tc": "TC-04", "description": "ensemble blank image — RULE D", **r})
    if r["error_code"] == ErrorCode.ENSEMBLE_BOTH_FAILED:
        rule_evidence["RULE_D"] = "EVIDENCED — TC-04"
    elif r["error_code"] == ErrorCode.ENSEMBLE_PARTIAL_FAILURE:
        rule_evidence["RULE_D"] = "PARTIAL — TC-04 only one failed (tesseract detected text)"
    print()

    # ─────────────────────────────────────────────────────────────────────────
    # TC-05 (prepared, not yet evidenced): RULE A — both succeed, exact match
    # Requires paddle available (Docker). Records harness structure only.
    # ─────────────────────────────────────────────────────────────────────────
    print("TC-05  RULE A — both backends succeed, text matches")
    print("       PENDING DOCKER: paddle requires libgomp.so.1 (not in Nix)")
    rule_evidence["RULE_A"] = "PENDING DOCKER"
    print()

    # ─────────────────────────────────────────────────────────────────────────
    # TC-06 (prepared, not yet evidenced): RULE B — both succeed, text mismatches
    # Requires paddle available (Docker). Records harness structure only.
    # ─────────────────────────────────────────────────────────────────────────
    print("TC-06  RULE B — both backends succeed, text differs")
    print("       PENDING DOCKER: paddle requires libgomp.so.1 (not in Nix)")
    rule_evidence["RULE_B"] = "PENDING DOCKER"
    print()

    # ─────────────────────────────────────────────────────────────────────────
    # TC-07: Unknown backend  (policy control)
    # Registry contains paddle+tesseract; request asks for "unknown_engine".
    # ─────────────────────────────────────────────────────────────────────────
    print("TC-07  backend=unknown_engine  (UNKNOWN_BACKEND control)")
    from app.backends.policy import select_backend as _sel
    _reg7 = BackendRegistry()
    _reg7.register("paddle",    paddle)
    _reg7.register("tesseract", tess)
    try:
        _sel(_reg7, requested_name="unknown_engine")
        r7 = {"success": True, "error_code": None, "error_message": None,
              "full_text": None, "mean_confidence": None, "ensemble_meta": None}
    except OCRServiceError as _e:
        r7 = {"success": False, "error_code": _e.code.value,
              "error_message": _e.message, "full_text": None,
              "mean_confidence": None, "ensemble_meta": None}
    r = {"label": "policy_check", "backend_name": "unknown_engine",
         "image_label": "N/A", **r7}
    print_result(r)
    results.append({"tc": "TC-07", "description": "unknown backend policy control", **r})
    print()

    # ─────────────────────────────────────────────────────────────────────────
    # Report
    # ─────────────────────────────────────────────────────────────────────────
    report = {
        "harness":           "seven7_ocr_service evidence harness v2.4",
        "generated_at":      started,
        "environment": {
            "paddle_available":    paddle.is_available,
            "paddle_reason":       paddle.unavailable_reason,
            "tesseract_available": tess.is_available,
            "tesseract_version":   getattr(tess, "_tess_version", None),
            "warmup_seconds":      warmup_s,
        },
        "rule_evidence":     rule_evidence,
        "test_cases":        results,
    }

    report_path = out_dir / "evidence_report.json"
    report_path.write_text(json.dumps(report, indent=2))

    print(f"{'='*62}")
    print("RULE EVIDENCE SUMMARY")
    print(f"{'='*62}")
    for rule, status in sorted(rule_evidence.items()):
        icon = "✓" if "EVIDENCED" in status else "…"
        print(f"  {icon}  {rule}: {status}")
    print()
    print(f"Evidence report written → {report_path}")
    print(f"{'='*62}\n")


if __name__ == "__main__":
    main()
