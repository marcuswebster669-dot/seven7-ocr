# seven7 OCR Microservice

Fail-closed OCR extraction service with PaddleOCR backend.

## Routes

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Liveness probe — always 200 if process is running |
| GET | `/ready` | Readiness probe — 503 if backend not loaded |
| POST | `/v1/ocr/extract` | OCR text extraction from uploaded image |

---

## Docker Validation

### Build

```bash
cd seven7_ocr_service
docker build -t seven7-ocr .
```

### Run

```bash
docker run -p 8000:8000 seven7-ocr
```

### Expected first-start behaviour

On first container startup, PaddleOCR downloads model weights before accepting
traffic. This is **expected warmup behaviour**, not an error.

```
INFO:app.main:seven7_ocr_service starting — running backend warmup …
INFO:app.backends.paddle_backend:PaddleOCR warmup starting …
# ... model download logs (50–200 MB, one-time) ...
INFO:app.backends.paddle_backend:PaddleOCR warmup complete.
INFO:app.main:Backend 'paddleocr' is ready.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000
```

Subsequent container starts reuse cached model weights if the model directory
is mounted as a volume:

```bash
docker run -p 8000:8000 -v paddle_models:/root/.paddleocr seven7-ocr
```

### Expected endpoint behaviour after warmup

| Endpoint | Expected response |
|----------|-------------------|
| `GET /health` | HTTP 200 `{"status":"ok"}` — always live |
| `GET /ready` | HTTP 200 `{"ready":true,"backend":"paddleocr","backend_status":"available"}` |
| `POST /v1/ocr/extract` (valid image with text) | HTTP 200 `{"success":true,...,"full_text":"...","words":[...]}` |
| `POST /v1/ocr/extract` (no file) | HTTP 422 FastAPI validation error |
| `POST /v1/ocr/extract` (corrupt image) | HTTP 200 `{"success":false,"error_code":"INVALID_IMAGE",...}` |

### Docker validation status

Docker build and runtime validation **cannot be executed in the current
Replit/Nix environment** — no Docker daemon is available.

Local Python runtime validation (without Docker) was completed successfully:

- Server starts in ~6 seconds
- `GET /health` → HTTP 200 confirmed
- `GET /ready` → HTTP 503 with `BACKEND_UNAVAILABLE` (libgomp.so.1 absent from Nix)
- `POST /v1/ocr/extract` valid PNG → HTTP 200, `success=false`, `error_code=BACKEND_UNAVAILABLE`,
  image decoded correctly (`image_width=200`, `image_height=64`)

The `libgomp.so.1` failure is a Nix-environment-only constraint. The Dockerfile
installs `libgomp1` via `apt-get` on `python:3.11-slim`, resolving it in Docker.

---

## Local Development

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

---

## POST /v1/ocr/extract

**Request** — multipart/form-data:

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `file` | file | yes | — | JPEG, PNG, BMP, TIFF, or WebP image |
| `min_confidence` | float [0,1] | no | 0.0 | Drop words below this confidence |
| `return_words` | bool | no | true | Include per-word results |

**Success response**:

```json
{
  "success": true,
  "request_id": "uuid",
  "backend_used": "paddleocr",
  "error_code": null,
  "error_message": null,
  "image_width": 640,
  "image_height": 480,
  "full_text": "Hello World",
  "mean_confidence": 0.9523,
  "words": [
    { "text": "Hello", "confidence": 0.97, "bbox": { "points": [[x,y], ...] } }
  ]
}
```

**Fail-closed error response** (`success=false`, never HTTP 5xx for app errors):

```json
{
  "success": false,
  "request_id": "uuid",
  "backend_used": "paddleocr",
  "error_code": "INVALID_IMAGE",
  "error_message": "Image could not be decoded.",
  "image_width": null,
  "image_height": null,
  "full_text": null,
  "mean_confidence": null,
  "words": []
}
```

---

## Error Codes

| Code | Trigger |
|------|---------|
| `EMPTY_UPLOAD` | No file bytes received |
| `INVALID_IMAGE` | Image could not be decoded by OpenCV |
| `IMAGE_TOO_LARGE` | Upload exceeds `MAX_IMAGE_BYTES` (default 20 MB) |
| `BACKEND_UNAVAILABLE` | PaddleOCR failed to initialise during warmup |
| `BACKEND_EXCEPTION` | PaddleOCR raised an exception during inference |
| `NO_TEXT_DETECTED` | OCR ran successfully but returned no text regions |

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8000` | Listen port |
| `LOG_LEVEL` | `info` | Logging level |
| `MAX_IMAGE_BYTES` | `20971520` | 20 MB upload limit |
| `DEFAULT_MIN_CONFIDENCE` | `0.0` | Default confidence threshold |
| `PADDLE_LANG` | `en` | PaddleOCR language |
| `PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK` | `True` | Skip connectivity check on startup |

---

## System Dependencies (Docker)

All installed via `apt-get` in the Dockerfile on `python:3.11-slim`:

| Package | Required by |
|---------|-------------|
| `libgomp1` | PaddlePaddle (GNU OpenMP runtime — hard requirement) |
| `libglib2.0-0` | OpenCV |
| `libsm6` | OpenCV (X11 session management) |
| `libxext6` | OpenCV (X11 extension) |
| `libxrender-dev` | OpenCV (X11 rendering) |
| `libgl1` | OpenCV (OpenGL) |
