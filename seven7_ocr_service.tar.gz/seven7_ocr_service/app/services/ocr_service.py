"""
services/ocr_service.py — Orchestrates backend execution and result assembly.

Applies confidence filtering, assembles the final OCRResponse.
Fail-closed: all OCRServiceErrors propagate; are caught in main.py.
"""

from __future__ import annotations

import statistics
import uuid
from typing import Optional

import numpy as np

from app.backends.base import OCRBackend
from app.errors import OCRServiceError
from app.schemas import BoundingBox, OCRResponse, WordResult


def run_ocr(
    backend:        OCRBackend,
    img_bgr:        np.ndarray,
    width:          int,
    height:         int,
    min_confidence: float,
    return_words:   bool,
) -> OCRResponse:
    """
    Run OCR via backend and build a structured OCRResponse.

    Parameters
    ----------
    backend        : loaded OCRBackend
    img_bgr        : decoded image (BGR)
    width / height : image dimensions (already validated)
    min_confidence : drop words below this confidence threshold
    return_words   : whether to populate the words[] list

    Returns
    -------
    OCRResponse with success=True

    Raises
    ------
    Any OCRServiceError subclass (caller catches and converts to success=False response)
    """
    request_id = str(uuid.uuid4())

    # May raise BackendUnavailableError, BackendExceptionError, NoTextDetectedError
    ocr_result = backend.run(img_bgr)

    # Apply confidence filter
    filtered = [w for w in ocr_result.words if w.confidence >= min_confidence]

    # Recompute full_text after filtering
    full_text = " ".join(w.text for w in filtered) if filtered else ""

    # mean_confidence
    confs = [w.confidence for w in filtered]
    mean_conf = round(statistics.mean(confs), 4) if confs else None

    # Build word list
    word_results = []
    if return_words:
        for w in filtered:
            bbox = BoundingBox(points=w.bbox) if w.bbox else None
            word_results.append(WordResult(
                text=w.text,
                confidence=round(w.confidence, 4),
                bbox=bbox,
            ))

    return OCRResponse(
        success=True,
        request_id=request_id,
        backend_used=backend.name,
        image_width=width,
        image_height=height,
        full_text=full_text,
        mean_confidence=mean_conf,
        words=word_results,
    )


def make_error_response(
    error:      OCRServiceError,
    backend:    str = "unknown",
    width:      Optional[int] = None,
    height:     Optional[int] = None,
) -> OCRResponse:
    """Build a fail-closed OCRResponse from any OCRServiceError."""
    return OCRResponse(
        success=False,
        request_id=str(uuid.uuid4()),
        backend_used=backend,
        error_code=error.code.value,
        error_message=error.message,
        image_width=width,
        image_height=height,
    )
