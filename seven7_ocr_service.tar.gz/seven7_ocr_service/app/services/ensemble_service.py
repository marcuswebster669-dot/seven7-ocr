"""
services/ensemble_service.py — Deterministic ensemble execution.

Ensemble mode is an explicit opt-in via backend="ensemble".
It is NOT a backend registered in the BackendRegistry.
It is NOT a fallback mechanism.

Adjudication rules (applied in strict order):

  RULE A — Both succeed, normalised full_text matches exactly
            → success=True,  backend_used="ensemble",  agreed text returned
  RULE B — Both succeed, normalised full_text differs
            → success=False, error_code=ENSEMBLE_MISMATCH, both texts in ensemble_meta
  RULE C — Exactly one succeeds, one fails or is unavailable
            → success=False, error_code=ENSEMBLE_PARTIAL_FAILURE
  RULE D — Both fail or are unavailable
            → success=False, error_code=ENSEMBLE_BOTH_FAILED

No silent fallback.
No automatic downgrade to single-backend execution.
No partial success.
"""

from __future__ import annotations

import re
import statistics
import uuid
from typing import Dict, Optional, Tuple

import numpy as np

from app.backends.base import OCRBackend
from app.errors import (
    EnsembleBothFailedError,
    EnsembleMismatchError,
    EnsemblePartialFailureError,
    OCRServiceError,
)
from app.schemas import BoundingBox, EnsembleBackendSummary, OCRResponse, WordResult
from app.services.ocr_service import run_ocr


# ── Normalisation ─────────────────────────────────────────────────────────────

def normalize_text(text: str) -> str:
    """
    Minimal normalisation for adjudication comparison only.
    - Strip leading/trailing whitespace
    - Collapse internal whitespace (spaces, tabs, newlines) to a single space
    Does NOT correct, infer, or reformat text in any other way.
    """
    return re.sub(r"\s+", " ", text.strip())


# ── Backend attempt ───────────────────────────────────────────────────────────

def _attempt(
    backend:        OCRBackend,
    img_bgr:        np.ndarray,
    width:          int,
    height:         int,
    min_confidence: float,
    return_words:   bool,
) -> Tuple[bool, object]:
    """
    Run a single backend. Returns (success, OCRResponse | OCRServiceError).
    Never raises.
    """
    try:
        result = run_ocr(
            backend=backend,
            img_bgr=img_bgr,
            width=width,
            height=height,
            min_confidence=min_confidence,
            return_words=return_words,
        )
        return True, result
    except OCRServiceError as err:
        return False, err


def _summarise(success: bool, result) -> EnsembleBackendSummary:
    """Build an EnsembleBackendSummary from an attempt result."""
    if success:
        r: OCRResponse = result
        return EnsembleBackendSummary(
            success=True,
            full_text=r.full_text,
            mean_confidence=r.mean_confidence,
        )
    else:
        err: OCRServiceError = result
        return EnsembleBackendSummary(
            success=False,
            error_code=err.code.value,
            error_message=err.message,
        )


# ── Ensemble entry point ──────────────────────────────────────────────────────

def run_ensemble(
    paddle_backend: OCRBackend,
    tess_backend:   OCRBackend,
    img_bgr:        np.ndarray,
    width:          int,
    height:         int,
    min_confidence: float,
    return_words:   bool,
) -> OCRResponse:
    """
    Run both backends and adjudicate per rules A → D.
    Always returns an OCRResponse (never raises OCRServiceError).
    """
    request_id = str(uuid.uuid4())

    paddle_ok, paddle_result = _attempt(
        paddle_backend, img_bgr, width, height, min_confidence, return_words
    )
    tess_ok, tess_result = _attempt(
        tess_backend, img_bgr, width, height, min_confidence, return_words
    )

    meta: Dict[str, EnsembleBackendSummary] = {
        paddle_backend.name: _summarise(paddle_ok, paddle_result),
        tess_backend.name:   _summarise(tess_ok,   tess_result),
    }

    # ── RULE A / RULE B — both succeeded ─────────────────────────────────────
    if paddle_ok and tess_ok:
        paddle_norm = normalize_text(paddle_result.full_text or "")
        tess_norm   = normalize_text(tess_result.full_text   or "")

        if paddle_norm == tess_norm:
            # RULE A — exact agreement
            return OCRResponse(
                success=True,
                request_id=request_id,
                backend_used="ensemble",
                image_width=width,
                image_height=height,
                full_text=paddle_norm,
                mean_confidence=_mean_conf(paddle_result, tess_result),
                words=paddle_result.words,   # both agree; use paddle's word list
                ensemble_meta=meta,
            )
        else:
            # RULE B — mismatch
            err = EnsembleMismatchError(
                paddle_text=paddle_result.full_text or "",
                tess_text=tess_result.full_text or "",
            )
            return OCRResponse(
                success=False,
                request_id=request_id,
                backend_used="ensemble",
                error_code=err.code.value,
                error_message=err.message,
                image_width=width,
                image_height=height,
                ensemble_meta=meta,
            )

    # ── RULE C — exactly one succeeded ───────────────────────────────────────
    if paddle_ok or tess_ok:
        failed_name  = tess_backend.name  if paddle_ok else paddle_backend.name
        failed_err   = tess_result        if paddle_ok else paddle_result
        err = EnsemblePartialFailureError(
            failed_backend=failed_name,
            reason=getattr(failed_err, "message", str(failed_err)),
        )
        return OCRResponse(
            success=False,
            request_id=request_id,
            backend_used="ensemble",
            error_code=err.code.value,
            error_message=err.message,
            image_width=width,
            image_height=height,
            ensemble_meta=meta,
        )

    # ── RULE D — both failed ─────────────────────────────────────────────────
    err = EnsembleBothFailedError(
        paddle_reason=getattr(paddle_result, "message", str(paddle_result)),
        tess_reason=getattr(tess_result,   "message", str(tess_result)),
    )
    return OCRResponse(
        success=False,
        request_id=request_id,
        backend_used="ensemble",
        error_code=err.code.value,
        error_message=err.message,
        image_width=width,
        image_height=height,
        ensemble_meta=meta,
    )


# ── Internal helpers ──────────────────────────────────────────────────────────

def _mean_conf(r1: OCRResponse, r2: OCRResponse) -> Optional[float]:
    """Average of two mean_confidences, or whichever is non-None."""
    vals = [v for v in (r1.mean_confidence, r2.mean_confidence) if v is not None]
    return round(statistics.mean(vals), 4) if vals else None
