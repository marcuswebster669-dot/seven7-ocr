"""
config.py — Application settings loaded from environment variables.
"""

import os


class Settings:
    # Server
    HOST: str   = os.environ.get("HOST", "0.0.0.0")
    PORT: int   = int(os.environ.get("PORT", "8100"))
    LOG_LEVEL: str = os.environ.get("LOG_LEVEL", "info")

    # Image limits
    MAX_IMAGE_BYTES: int = int(os.environ.get("MAX_IMAGE_BYTES", str(20 * 1024 * 1024)))  # 20 MB

    # OCR defaults
    DEFAULT_MIN_CONFIDENCE: float = float(os.environ.get("DEFAULT_MIN_CONFIDENCE", "0.0"))
    DEFAULT_RETURN_WORDS: bool    = os.environ.get("DEFAULT_RETURN_WORDS", "true").lower() == "true"

    # PaddleOCR
    PADDLE_LANG: str        = os.environ.get("PADDLE_LANG", "en")
    PADDLE_USE_ANGLE_CLS: bool = (
        os.environ.get("PADDLE_USE_ANGLE_CLS", "false").lower() == "true"
    )
    PADDLE_DISABLE_MODEL_SOURCE_CHECK: bool = (
        os.environ.get("PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK", "true").lower() == "true"
    )


settings = Settings()
