"""
errors.py — Error codes and exception hierarchy.

Fail-closed: every error path has an explicit code and message.
"""

from enum import Enum


class ErrorCode(str, Enum):
    EMPTY_UPLOAD             = "EMPTY_UPLOAD"
    INVALID_IMAGE            = "INVALID_IMAGE"
    IMAGE_TOO_LARGE          = "IMAGE_TOO_LARGE"
    UNKNOWN_BACKEND          = "UNKNOWN_BACKEND"
    BACKEND_UNAVAILABLE      = "BACKEND_UNAVAILABLE"
    BACKEND_EXCEPTION        = "BACKEND_EXCEPTION"
    NO_TEXT_DETECTED         = "NO_TEXT_DETECTED"
    ENSEMBLE_MISMATCH        = "ENSEMBLE_MISMATCH"
    ENSEMBLE_PARTIAL_FAILURE = "ENSEMBLE_PARTIAL_FAILURE"
    ENSEMBLE_BOTH_FAILED     = "ENSEMBLE_BOTH_FAILED"


class OCRServiceError(Exception):
    """Base class for all fail-closed OCR service errors."""
    def __init__(self, code: ErrorCode, message: str):
        super().__init__(message)
        self.code    = code
        self.message = message


class EmptyUploadError(OCRServiceError):
    def __init__(self):
        super().__init__(ErrorCode.EMPTY_UPLOAD, "No image file was provided in the request.")


class InvalidImageError(OCRServiceError):
    def __init__(self, detail: str = ""):
        msg = f"Image could not be decoded. {detail}".strip()
        super().__init__(ErrorCode.INVALID_IMAGE, msg)


class ImageTooLargeError(OCRServiceError):
    def __init__(self, size_bytes: int, limit_bytes: int):
        super().__init__(
            ErrorCode.IMAGE_TOO_LARGE,
            f"Image size {size_bytes} bytes exceeds limit {limit_bytes} bytes.",
        )


class UnknownBackendError(OCRServiceError):
    def __init__(self, requested: str, known: list):
        known_str = ", ".join(known) if known else "(none registered)"
        super().__init__(
            ErrorCode.UNKNOWN_BACKEND,
            f"Backend '{requested}' is not registered. Known backends: {known_str}.",
        )


class BackendUnavailableError(OCRServiceError):
    def __init__(self, reason: str = ""):
        msg = f"OCR backend is not available. {reason}".strip()
        super().__init__(ErrorCode.BACKEND_UNAVAILABLE, msg)


class BackendExceptionError(OCRServiceError):
    def __init__(self, detail: str):
        super().__init__(ErrorCode.BACKEND_EXCEPTION, f"OCR backend raised an exception: {detail}")


class NoTextDetectedError(OCRServiceError):
    def __init__(self):
        super().__init__(ErrorCode.NO_TEXT_DETECTED, "OCR backend returned no text for this image.")


class EnsembleMismatchError(OCRServiceError):
    def __init__(self, paddle_text: str, tess_text: str):
        super().__init__(
            ErrorCode.ENSEMBLE_MISMATCH,
            f"Ensemble backends returned different texts. "
            f"paddle={paddle_text!r}  tesseract={tess_text!r}",
        )


class EnsemblePartialFailureError(OCRServiceError):
    def __init__(self, failed_backend: str, reason: str = ""):
        super().__init__(
            ErrorCode.ENSEMBLE_PARTIAL_FAILURE,
            f"Ensemble requires both backends to succeed; '{failed_backend}' failed. {reason}".strip(),
        )


class EnsembleBothFailedError(OCRServiceError):
    def __init__(self, paddle_reason: str = "", tess_reason: str = ""):
        super().__init__(
            ErrorCode.ENSEMBLE_BOTH_FAILED,
            f"Both ensemble backends failed. paddle=({paddle_reason}) tesseract=({tess_reason})",
        )
