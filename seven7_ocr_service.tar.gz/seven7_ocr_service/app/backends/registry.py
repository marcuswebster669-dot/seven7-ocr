"""
backends/registry.py — Backend registry.

Stores named OCRBackend instances registered at startup.
Provides deterministic name-based lookup; no implicit switching.

Usage:
    from app.backends.registry import registry
    registry.register("paddle", PaddleOCRBackend())
    backend = registry.get("paddle")   # None if not registered
"""

from __future__ import annotations

from typing import Dict, List, Optional

from app.backends.base import OCRBackend

DEFAULT_BACKEND_NAME: str = "paddle"


class BackendRegistry:
    """
    Thread-safe-by-construction registry (populated once at startup, read-only after).
    No silent fallback.  Callers must check availability explicitly.
    """

    def __init__(self) -> None:
        self._backends: Dict[str, OCRBackend] = {}

    # ── Mutation (startup only) ──────────────────────────────────────────────

    def register(self, name: str, backend: OCRBackend) -> None:
        """Register a backend under the given name. Overwrites on duplicate."""
        self._backends[name] = backend

    # ── Query (read-only after startup) ─────────────────────────────────────

    def get(self, name: str) -> Optional[OCRBackend]:
        """Return the backend for name, or None if not registered."""
        return self._backends.get(name)

    def names(self) -> List[str]:
        """Return sorted list of all registered backend names."""
        return sorted(self._backends.keys())

    def status_map(self) -> Dict[str, str]:
        """
        Return {name: "available" | "unavailable"} for all registered backends.
        Used by /ready to report structured backend status.
        """
        return {
            name: ("available" if b.is_available else "unavailable")
            for name, b in self._backends.items()
        }

    def default_name(self) -> str:
        return DEFAULT_BACKEND_NAME


# ── Module-level singleton ───────────────────────────────────────────────────
registry = BackendRegistry()
