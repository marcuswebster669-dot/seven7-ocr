"""
backends/paddle_backend.py — PaddleOCR backend implementation.

Fail-closed:
  - Import failure        → is_available = False
  - Init failure          → is_available = False
  - run() on unavailable  → raises BackendUnavailableError
  - Paddle exception      → raises BackendExceptionError
  - No text returned      → raises NoTextDetectedError
"""

from __future__ import annotations

import logging
import os
import traceback
from typing import List, Optional

import numpy as np

from app.backends.base import OCRBackend, BackendOCRResult, WordDetection
from app.config import settings
from app.errors import BackendUnavailableError, BackendExceptionError, NoTextDetectedError

log = logging.getLogger(__name__)


class PaddleOCRBackend(OCRBackend):
    """PaddleOCR 3.x backend."""

    def __init__(self) -> None:
        self._ocr          = None
        self._available    = False
        self._unavail_reason: Optional[str] = None

        if settings.PADDLE_DISABLE_MODEL_SOURCE_CHECK:
            os.environ["PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK"] = "True"

        self._try_import()

    # ── OCRBackend interface ────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "paddleocr"

    @property
    def is_available(self) -> bool:
        return self._available

    @property
    def unavailable_reason(self) -> Optional[str]:
        return self._unavail_reason

    def warmup(self) -> None:
        """
        Initialise PaddleOCR model and run a dummy 64×200 white image.
        Sets is_available = True on success, False on any error.
        """
        if not self._available:
            log.warning("PaddleOCR warmup skipped: backend not importable. reason=%s",
                        self._unavail_reason)
            return

        log.info("PaddleOCR warmup starting …")
        try:
            self._init_ocr()
            dummy = np.full((64, 200, 3), 200, dtype=np.uint8)
            self._ocr.ocr(dummy)
            log.info("PaddleOCR warmup complete.")
        except Exception as exc:
            self._available       = False
            self._unavail_reason  = f"warmup_failed: {exc}"
            log.error("PaddleOCR warmup failed: %s\n%s", exc, traceback.format_exc()[-600:])

    def run(self, img_bgr: np.ndarray) -> BackendOCRResult:
        """
        Run PaddleOCR on a BGR numpy array.

        Raises
        ------
        BackendUnavailableError  — backend not loaded
        BackendExceptionError    — Paddle raised an exception
        NoTextDetectedError      — no text found in image
        """
        if not self._available:
            raise BackendUnavailableError(self._unavail_reason or "")

        try:
            result = self._ocr.ocr(img_bgr)
        except Exception as exc:
            raise BackendExceptionError(str(exc)) from exc

        words = self._parse_result(result)

        if not words:
            raise NoTextDetectedError()

        full_text = " ".join(w.text for w in words)
        return BackendOCRResult(words=words, full_text=full_text, backend=self.name)

    # ── Internal helpers ────────────────────────────────────────────────────

    def _try_import(self) -> None:
        """Attempt to import paddleocr.  Sets _available accordingly."""
        try:
            import paddleocr  # noqa: F401 — import check only
            self._available = True
        except ImportError as exc:
            self._available       = False
            self._unavail_reason  = f"import_failed: {exc}"
            log.warning("PaddleOCR import failed: %s", exc)
        except Exception as exc:
            self._available       = False
            self._unavail_reason  = f"import_exception: {exc}"
            log.warning("PaddleOCR import raised unexpected exception: %s", exc)

    def _init_ocr(self) -> None:
        """Lazy-init the PaddleOCR instance (called during warmup)."""
        if self._ocr is not None:
            return
        from paddleocr import PaddleOCR

        # PaddleOCR 3.x API — only accepted keyword arguments
        self._ocr = PaddleOCR(
            lang=settings.PADDLE_LANG,
            use_textline_orientation=settings.PADDLE_USE_ANGLE_CLS,
            use_doc_orientation_classify=False,
            use_doc_unwarping=False,
        )

    @staticmethod
    def _parse_result(result) -> List[WordDetection]:
        """
        Parse PaddleOCR result list into WordDetection objects.

        PaddleOCR 3.x returns:
          result[0] = list of detections
          detection = [box_coords, [text, confidence]]
        """
        words: List[WordDetection] = []
        if not result or result[0] is None:
            return words

        for item in result[0]:
            if item is None:
                continue
            try:
                if isinstance(item, (list, tuple)) and len(item) == 2:
                    box, payload = item
                    if isinstance(payload, (list, tuple)) and len(payload) == 2:
                        text, conf = payload
                        text = str(text).strip()
                        if text:
                            words.append(WordDetection(
                                text=text,
                                confidence=float(conf),
                                bbox=box if isinstance(box, list) else None,
                            ))
            except Exception:
                continue

        return words
