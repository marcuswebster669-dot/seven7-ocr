"""
backends/tesseract_backend.py — Tesseract OCR backend implementation.

Fail-closed behaviour (mirrors paddle_backend.py pattern):
  - pytesseract import failure  → is_available = False
  - tesseract binary missing    → is_available = False
  - warmup failure              → is_available = False
  - run() on unavailable        → raises BackendUnavailableError
  - pytesseract exception       → raises BackendExceptionError
  - no text returned            → raises NoTextDetectedError

Requires:
  - tesseract binary in PATH  (apt: tesseract-ocr / nix: tesseract)
  - pytesseract Python package
  - Pillow (PIL)
  - opencv-python (for BGR→RGB conversion)
"""

from __future__ import annotations

import logging
import traceback
from typing import List, Optional

import numpy as np

from app.backends.base import BackendOCRResult, OCRBackend, WordDetection
from app.errors import BackendExceptionError, BackendUnavailableError, NoTextDetectedError

log = logging.getLogger(__name__)


class TesseractBackend(OCRBackend):
    """Tesseract 4/5 backend via pytesseract."""

    # Tesseract page-segmentation mode: 11 = sparse text (no word ordering assumed).
    # Good for short game-UI labels and resource panels.
    _PSM = 11

    def __init__(self) -> None:
        self._available: bool = False
        self._unavail_reason: Optional[str] = None
        self._tess_version: Optional[str] = None

        self._try_import()

    # ── OCRBackend interface ────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "tesseract"

    @property
    def is_available(self) -> bool:
        return self._available

    @property
    def unavailable_reason(self) -> Optional[str]:
        return self._unavail_reason

    def warmup(self) -> None:
        """
        Verify tesseract binary is reachable and run a dummy inference.
        Sets is_available = True on success, False on any error.
        """
        if not self._available:
            log.warning(
                "Tesseract warmup skipped: import or binary check failed. reason=%s",
                self._unavail_reason,
            )
            return

        log.info("Tesseract warmup starting …")
        try:
            import pytesseract
            from PIL import Image

            # Confirm binary version is accessible
            ver = pytesseract.get_tesseract_version()
            self._tess_version = str(ver)
            log.info("Tesseract binary version: %s", self._tess_version)

            # Dummy inference on a small white image
            dummy_pil = Image.fromarray(
                np.full((32, 128, 3), 255, dtype=np.uint8)
            )
            pytesseract.image_to_string(dummy_pil, config=f"--psm {self._PSM}")

            self._available = True
            log.info("Tesseract warmup complete.")

        except Exception as exc:
            self._available = False
            self._unavail_reason = f"warmup_failed: {exc}"
            log.error(
                "Tesseract warmup failed: %s\n%s", exc, traceback.format_exc()[-600:]
            )

    def run(self, img_bgr: np.ndarray) -> BackendOCRResult:
        """
        Run Tesseract OCR on a BGR numpy array.

        Raises
        ------
        BackendUnavailableError  — backend not loaded
        BackendExceptionError    — pytesseract raised an exception
        NoTextDetectedError      — no text found in image
        """
        if not self._available:
            raise BackendUnavailableError(self._unavail_reason or "")

        try:
            import cv2
            import pytesseract
            from PIL import Image
            from pytesseract import Output

            # BGR → RGB → PIL
            img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(img_rgb)

            data = pytesseract.image_to_data(
                pil_img,
                config=f"--psm {self._PSM}",
                output_type=Output.DICT,
            )

        except Exception as exc:
            raise BackendExceptionError(str(exc)) from exc

        words = self._parse_result(data)

        if not words:
            raise NoTextDetectedError()

        full_text = " ".join(w.text for w in words)
        return BackendOCRResult(words=words, full_text=full_text, backend=self.name)

    # ── Internal helpers ────────────────────────────────────────────────────

    def _try_import(self) -> None:
        """
        Attempt to import pytesseract and verify the tesseract binary is on PATH.
        Sets _available accordingly without raising.
        """
        try:
            import pytesseract  # noqa: F401 — import check

            # Verify binary is reachable before marking importable
            import shutil
            if shutil.which("tesseract") is None:
                self._available = False
                self._unavail_reason = "binary_missing: tesseract not found in PATH"
                log.warning("Tesseract binary not found in PATH.")
                return

            self._available = True

        except ImportError as exc:
            self._available = False
            self._unavail_reason = f"import_failed: {exc}"
            log.warning("pytesseract import failed: %s", exc)
        except Exception as exc:
            self._available = False
            self._unavail_reason = f"import_exception: {exc}"
            log.warning("pytesseract import raised unexpected exception: %s", exc)

    @staticmethod
    def _parse_result(data: dict) -> List[WordDetection]:
        """
        Parse pytesseract image_to_data dict into WordDetection objects.

        data keys: level, page_num, block_num, par_num, line_num, word_num,
                   left, top, width, height, conf, text
        conf is -1 for non-word rows and 0-100 for word rows.
        """
        words: List[WordDetection] = []
        n = len(data.get("text", []))

        for i in range(n):
            try:
                conf = float(data["conf"][i])
                text = str(data["text"][i]).strip()

                if conf < 0 or not text:
                    continue

                left   = float(data["left"][i])
                top    = float(data["top"][i])
                width  = float(data["width"][i])
                height = float(data["height"][i])

                # 4-corner polygon consistent with PaddleOCR output format
                bbox = [
                    [left,          top],
                    [left + width,  top],
                    [left + width,  top + height],
                    [left,          top + height],
                ]

                words.append(WordDetection(
                    text=text,
                    confidence=round(conf / 100.0, 4),
                    bbox=bbox,
                ))
            except Exception:
                continue

        return words
