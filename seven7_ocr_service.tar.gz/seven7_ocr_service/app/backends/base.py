"""
backends/base.py — Abstract base class for OCR backends.

All backends must implement this interface.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class WordDetection:
    text:       str
    confidence: float
    bbox:       Optional[List[List[float]]] = None   # [[x,y],[x,y],[x,y],[x,y]]


@dataclass
class BackendOCRResult:
    words:      List[WordDetection] = field(default_factory=list)
    full_text:  str                  = ""
    backend:    str                  = ""


class OCRBackend(ABC):
    """Abstract OCR backend.  Concrete implementations must be fail-closed."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable backend identifier."""

    @property
    @abstractmethod
    def is_available(self) -> bool:
        """True iff the backend loaded successfully and is ready."""

    @property
    def unavailable_reason(self) -> Optional[str]:
        """If not available, a short explanation. May be None if available."""
        return None

    @abstractmethod
    def warmup(self) -> None:
        """
        Run a lightweight warmup pass (e.g. model load, dummy inference).
        Called once at startup. Must not raise — log and set is_available=False instead.
        """

    @abstractmethod
    def run(self, img_bgr) -> BackendOCRResult:
        """
        Run OCR on a BGR numpy array.

        Raises
        ------
        BackendUnavailableError  — if is_available is False
        BackendExceptionError    — on any internal exception
        """
