"""
backends/policy.py — Deterministic backend selection policy.

Rules (applied in order, fail-closed):
  1. If requested_name is None → use registry default ("paddle")
  2. If requested_name is not in registry → raise UnknownBackendError
  3. If backend is registered but is_available=False → raise BackendUnavailableError
  4. Return the backend

NO silent fallback.
NO automatic switching to another backend.
NO ensemble execution.
"""

from __future__ import annotations

from typing import Optional

from app.backends.base import OCRBackend
from app.backends.registry import BackendRegistry
from app.errors import BackendUnavailableError, UnknownBackendError


def select_backend(
    registry:       BackendRegistry,
    requested_name: Optional[str] = None,
) -> OCRBackend:
    """
    Apply the deterministic backend selection policy.

    Parameters
    ----------
    registry       : populated BackendRegistry (from startup)
    requested_name : caller-supplied backend name, or None to use default

    Returns
    -------
    A ready OCRBackend instance.

    Raises
    ------
    UnknownBackendError     — requested_name is not in registry
    BackendUnavailableError — backend is registered but not available
    """
    name = requested_name if requested_name is not None else registry.default_name()

    backend = registry.get(name)

    # RULE 2 — unknown backend
    if backend is None:
        raise UnknownBackendError(
            requested=name,
            known=registry.names(),
        )

    # RULE 3 — known but unavailable
    if not backend.is_available:
        raise BackendUnavailableError(backend.unavailable_reason or "")

    # RULE 4 — ready
    return backend
