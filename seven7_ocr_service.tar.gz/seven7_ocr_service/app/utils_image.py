"""
utils_image.py — Image validation and decoding.

Fail-closed: any invalid or oversized image raises an explicit OCRServiceError.
Never returns None silently.
"""

from __future__ import annotations

import io
import numpy as np

from app.config import settings
from app.errors import InvalidImageError, ImageTooLargeError, EmptyUploadError


def validate_and_decode(data: bytes) -> tuple[np.ndarray, int, int]:
    """
    Validate image bytes and decode to a BGR numpy array.

    Parameters
    ----------
    data : raw bytes of the uploaded file

    Returns
    -------
    (img_bgr, width, height)

    Raises
    ------
    EmptyUploadError       — data is empty
    ImageTooLargeError     — data exceeds MAX_IMAGE_BYTES
    InvalidImageError      — data cannot be decoded as an image
    """
    if not data:
        raise EmptyUploadError()

    if len(data) > settings.MAX_IMAGE_BYTES:
        raise ImageTooLargeError(len(data), settings.MAX_IMAGE_BYTES)

    # Lazy import to keep startup fast
    try:
        import cv2
    except ImportError:
        raise InvalidImageError("opencv-python not installed")

    buf = np.frombuffer(data, dtype=np.uint8)
    img = cv2.imdecode(buf, cv2.IMREAD_COLOR)

    if img is None:
        raise InvalidImageError("cv2.imdecode returned None — unsupported format or corrupt data.")

    h, w = img.shape[:2]
    if h == 0 or w == 0:
        raise InvalidImageError(f"Decoded image has zero dimension: {w}x{h}.")

    return img, w, h
