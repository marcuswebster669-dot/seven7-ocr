"""
schemas.py — Pydantic request and response models.
"""

from __future__ import annotations

from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class BoundingBox(BaseModel):
    """Four-point polygon [[x,y], [x,y], [x,y], [x,y]] in image pixel coordinates."""
    points: List[List[float]]


class WordResult(BaseModel):
    text:       str
    confidence: float
    bbox:       Optional[BoundingBox] = None


class EnsembleBackendSummary(BaseModel):
    """Per-backend result summary included in ensemble_meta."""
    success:         bool
    full_text:       Optional[str]   = None
    mean_confidence: Optional[float] = None
    error_code:      Optional[str]   = None
    error_message:   Optional[str]   = None


class OCRResponse(BaseModel):
    success:         bool
    request_id:      str
    backend_used:    str

    error_code:      Optional[str]   = None
    error_message:   Optional[str]   = None

    image_width:     Optional[int]   = None
    image_height:    Optional[int]   = None

    full_text:       Optional[str]   = None
    mean_confidence: Optional[float] = None
    words:           List[WordResult] = Field(default_factory=list)

    # Populated only when backend_used="ensemble"; null for single-backend requests.
    ensemble_meta:   Optional[Dict[str, EnsembleBackendSummary]] = Field(default=None)


class HealthResponse(BaseModel):
    status: str   # "ok"


class ReadyResponse(BaseModel):
    ready:          bool
    backend:        str
    backend_status: str            # "available" | "unavailable"
    reason:         Optional[str] = None
    backends:       Dict[str, str] = Field(default_factory=dict)
    # backends: {name: "available" | "unavailable"} for all registered backends
