"""
main.py — FastAPI application entry point.

Routes:
  GET  /health              — liveness probe
  GET  /ready               — readiness probe (backend must be available)
  POST /v1/ocr/extract      — OCR extraction

Startup:
  Backend warmup runs once before accepting traffic.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Annotated, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile, status
from fastapi.responses import JSONResponse

from app.backends.paddle_backend import PaddleOCRBackend
from app.backends.tesseract_backend import TesseractBackend
from app.backends.policy import select_backend
from app.backends.registry import registry
from app.config import settings
from app.errors import OCRServiceError, UnknownBackendError
from app.schemas import HealthResponse, OCRResponse, ReadyResponse
from app.services.ensemble_service import run_ensemble
from app.services.ocr_service import make_error_response, run_ocr
from app.utils_image import validate_and_decode

_ENSEMBLE_KEY = "ensemble"   # reserved keyword; not a registry entry

logging.basicConfig(level=settings.LOG_LEVEL.upper())
log = logging.getLogger(__name__)

# ── Singleton backends ────────────────────────────────────────────────────────
_backend      = PaddleOCRBackend()
_tess_backend = TesseractBackend()


def _warmup_and_register(backend, canonical_name: str) -> None:
    """Warmup a backend and register it under canonical_name. Never raises."""
    backend.warmup()
    registry.register(canonical_name, backend)
    if backend.is_available:
        log.info("Backend '%s' is ready.", canonical_name)
    else:
        log.warning(
            "Backend '%s' is NOT available. reason=%s  "
            "Requests to this backend will return BACKEND_UNAVAILABLE.",
            canonical_name,
            backend.unavailable_reason,
        )


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("seven7_ocr_service starting — running backend warmup …")
    _warmup_and_register(_backend,      "paddle")
    _warmup_and_register(_tess_backend, "tesseract")
    log.info("Registered backends: %s", registry.names())
    yield
    log.info("seven7_ocr_service shutdown.")


app = FastAPI(
    title="seven7 OCR Microservice",
    version="1.0.0",
    description="Fail-closed OCR extraction service with PaddleOCR backend.",
    lifespan=lifespan,
)


# ── GET /health ──────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["ops"])
async def health() -> HealthResponse:
    """Liveness probe — always returns 200 if the process is running."""
    return HealthResponse(status="ok")


# ── GET /ready ───────────────────────────────────────────────────────────────

@app.get(
    "/ready",
    response_model=ReadyResponse,
    tags=["ops"],
    responses={503: {"description": "Backend unavailable"}},
)
async def ready() -> ReadyResponse:
    """Readiness probe — returns 503 if the default OCR backend is not loaded."""
    available = _backend.is_available
    resp = ReadyResponse(
        ready=available,
        backend=registry.default_name(),
        backend_status="available" if available else "unavailable",
        reason=_backend.unavailable_reason if not available else None,
        backends=registry.status_map(),
    )
    if not available:
        return JSONResponse(status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                            content=resp.model_dump())
    return resp


# ── POST /v1/ocr/extract ─────────────────────────────────────────────────────

@app.post(
    "/v1/ocr/extract",
    response_model=OCRResponse,
    tags=["ocr"],
    summary="Extract text from an uploaded image",
)
async def ocr_extract(
    file:           UploadFile = File(..., description="Image file (JPEG, PNG, BMP, TIFF, WebP)"),
    min_confidence: Annotated[float, Form(ge=0.0, le=1.0)] = settings.DEFAULT_MIN_CONFIDENCE,
    return_words:   Annotated[bool,  Form()] = settings.DEFAULT_RETURN_WORDS,
    backend:        Annotated[Optional[str], Form(
                        description=(
                            "Backend name. Omit to use default (paddle). "
                            "Use 'ensemble' to run both paddle and tesseract with "
                            "deterministic adjudication. Unknown names fail closed."
                        )
                    )] = None,
) -> OCRResponse:
    """
    Extract text from an uploaded image.

    Backend selection policy (deterministic, fail-closed):
    - backend omitted            → default backend (paddle)
    - backend="ensemble"         → run both paddle + tesseract; adjudicate per rules A-D
    - backend=<registered name>  → use if available, else BACKEND_UNAVAILABLE
    - backend=<unknown name>     → UNKNOWN_BACKEND

    On any error, success=false with explicit error_code and error_message.
    Never raises HTTP 5xx for application-level failures.
    """
    is_ensemble = (backend == _ENSEMBLE_KEY)

    # ── Backend validation (fail fast before reading upload) ──────────────────
    if not is_ensemble:
        try:
            active_backend = select_backend(registry, requested_name=backend)
        except OCRServiceError as err:
            return make_error_response(err, backend=backend or registry.default_name())
    else:
        active_backend = None   # ensemble path; unused below

    backend_label = _ENSEMBLE_KEY if is_ensemble else active_backend.name

    # ── Read upload ───────────────────────────────────────────────────────────
    try:
        data = await file.read()
    except Exception as exc:
        from app.errors import InvalidImageError
        err = InvalidImageError(f"Failed to read upload: {exc}")
        return make_error_response(err, backend=backend_label)

    # ── Validate and decode image ─────────────────────────────────────────────
    try:
        img_bgr, w, h = validate_and_decode(data)
    except OCRServiceError as err:
        return make_error_response(err, backend=backend_label)

    # ── Dispatch ──────────────────────────────────────────────────────────────
    if is_ensemble:
        # run_ensemble handles all rules A-D internally; never raises.
        return run_ensemble(
            paddle_backend=_backend,
            tess_backend=_tess_backend,
            img_bgr=img_bgr,
            width=w,
            height=h,
            min_confidence=min_confidence,
            return_words=return_words,
        )

    try:
        return run_ocr(
            backend=active_backend,
            img_bgr=img_bgr,
            width=w,
            height=h,
            min_confidence=min_confidence,
            return_words=return_words,
        )
    except OCRServiceError as err:
        return make_error_response(err, backend=active_backend.name, width=w, height=h)
